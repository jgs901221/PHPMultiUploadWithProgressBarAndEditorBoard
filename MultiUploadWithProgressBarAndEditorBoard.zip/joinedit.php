﻿<?php 
header("Content-Type: text/html; charset=UTF-8"); 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>공돌이광식</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
* {
    box-sizing:border-box;
}
@font-face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}
header {
    margin-top:0px;
    padding:15px;
    width:100%;
    height:100px;
    background:black;
    text-align:center;
    font-size:60px;
    font-family:"나눔바른펜 굵게";
}
header a, nav a {
    text-decoration:none;
    color:white;
}
nav {
    width:100%;
    height:50px;
    margin-top:10px;
    padding:10px;
    background:black;
    color:white;
    font-size:30px;
    font-family:"나눔바른펜 굵게";
}
footer {
    position: fixed;
    bottom:0;
}
div {
    border:1px solid;
    border-radius:10px;
    padding:10px;
    width:50%;
    margin:10px;
    margin-left:auto;
    margin-right:auto;
}
.text{
    width:100%;
    margin:10px 0;
    padding:3px;
    border:1px solid;
    border-radius:5px;
    display:inline-block;
}
span {
    color:red;
    font-size:12px;
}
</style>
</head>
<body>
<nav>
<a href="main.php">공돌이광식</a>
<a href="logout.php" style="float:right;">로그아웃</a>
<?php 
include 'db.php'; 
if(!(isset($_SESSION['id'])&&isset($_SESSION['username']))) {
echo "<script>location.href='/main.php';</script>";
}
$sql = "select *from member where id='".$_SESSION['id']."' and name='".$_SESSION['username']."'";
$res = $conn->query($sql);
$row = mysqli_fetch_array($res);
?>
</nav>
<div>
<form method="post" action="/joindbupdate.php">
<label>비밀번호<br><span id="pc1"></span></label>
<input class="text" id="p1" name="password" type="password" onkeyup="passwordcheck(this.value)" placeholder="영문,숫자,특수문자를 포함한  8~20자리" maxlength="20">
<label>비밀번호 확인<br><span id="pc2"></span></label>
<input class="text" id="p2" name="password2" type="password" onkeyup="passwordcheck2(this.value)" maxlength="20">
<input type="hidden" id="h" name="hidden" value="">
<label>주소</label>
<input class="text" type="text" id="a" name="address" onkeyup="addresscheck()" placeholder="한글,영문,숫자,특수기호  (-),(_),(,),(@)만 입력 허용 입력 허용" maxlength="139" value="<?php echo $row['address'];?>">
<label>휴대폰 번호(예:01020190000)</label><span id="test2"></span>
<input class="text" type="text" id="nb" name="number" onkeyup="numbercheck(this.value)" placeholder="숫자만 입력 허용" maxlength="11" value="<?php echo $row['number'];?>">
<input type="hidden" id="h3" name="hidden3" value="1">
<label>이메일<br><span id="ec"></span></label>
<input class="text" type="email" id="e" name="email" onkeyup="emailaddress(this.value)" placeholder="입력이 허용되는 특수문자는 (@),(_),(-),(.)입니다." maxlength="100" value="<?php echo $row['email'];?>">
<input type="hidden" id="h4" name="hidden4" value="1">
<input type="submit" value="제출">
</form>
</div>
<footer>&copy; 2019 by 공돌이광식</footer>
<script>
function addresscheck() {
	document.getElementById("a").value = document.getElementById("a").value.replace(/[^ㄱ-ㅎㅏ-ㅣ가-힣a-zA-Z0-9, .@_-]/g,"");
}

function emailaddress(e) {
document.getElementById("e").value = document.getElementById("e").value.replace(/[^0-9a-zA-Z@_.-]/g,"");
var emailvalue = /^[0-9a-zA-Z-_.]([-_.]?[0-9a-zA-Z-_.])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i;//이메일 정규식
if(emailvalue.test(e)==false) {
	document.getElementById("ec").innerHTML = "입력이 허용되는 특수문자는 (@),(_),(-),(.)입니다.";
	document.getElementById("h4").value = "";
            return false;
} else {
	document.getElementById("ec").innerHTML = "";
	document.getElementById("h4").value = "1";
}
}

function passwordcheck(pw) {
	var pwc = document.getElementById("p1").value.replace(/(\s*)/g,"");
	document.getElementById("p1").value = pwc;
	var num = pw.search(/[0-9]/g);
	var eng = pw.search(/[a-z]/ig);
	var spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi);
		if(document.getElementById("p1").value.length < 8) { //8자리 이하일 경우
			document.getElementById("pc1").innerHTML = "영문, 숫자, 특수문자를 포함한  8자리 이상 입력하세요.";
			document.getElementById("pc2").innerHTML = "";
			document.getElementById("h").value = "";
			return false;
		} else { //8자리 이상일 경우
			if((eng >= 0) &&  (num >= 0) && (spe >= 0)){ //영문,숫자,특수문자를 포함하고 있을 경우
				document.getElementById("pc1").innerHTML = "";
				if((document.getElementById("p1").value == document.getElementById("p2").value)) {
					document.getElementById("pc2").innerHTML = "비밀번호가 확인되었습니다.";
					document.getElementById("h").value = "1";
				} else {
					document.getElementById("pc2").innerHTML = "";
					document.getElementById("h").value = "";
				}
			} else { //영문,숫자,특수 문자 중 하나라도 포함하지 않고 있을 경우
				document.getElementById("pc1").innerHTML = "영문, 숫자, 특수문자를 포함한  8자리 이상 입력하세요.";
				document.getElementById("pc2").innerHTML = "";
				document.getElementById("h").value = "";
				return false;
			}
		}
}

function passwordcheck2(pw) {
	var pwc = document.getElementById("p2").value.replace(/(\s*)/g,"");
	document.getElementById("p2").value = pwc;
	var num = pw.search(/[0-9]/g);
	var eng = pw.search(/[a-z]/ig);
	var spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi);
	if(document.getElementById("p1").value == document.getElementById("p2").value) { //p1과 p2의 값이 같을 경우
		if(((eng >= 0) &&  (num >= 0) && (spe >= 0))&&(document.getElementById("p2").value.length >= 8)) { //특수문자가 포함이 되어 있고, 길이가 8이상이라면
			document.getElementById("pc2").innerHTML = "비밀번호가 확인되었습니다.";
			document.getElementById("h").value = "1";
		} else { //다른 경우라면
			document.getElementById("pc2").innerHTML = "";
			document.getElementById("h").value = "";
			return false;
		}
	} else { //다른 경우라면
		document.getElementById("pc2").innerHTML = "";
		document.getElementById("h").value = "";
	}
}	

function numbercheck(nb) {
	var numbervalue = /^(0[1][0-1][0-9]{7,8})$/;
	if(numbervalue.test(nb)) {
		document.getElementById("test2").innerHTML = "";
		document.getElementById("h3").value = "1";
	} else {
		document.getElementById("test2").innerHTML = "예) 01020190000";
		document.getElementById("h3").value = "";
	}
	document.getElementById("nb").value = document.getElementById("nb").value.replace(/[^0-9]/g,"");
}
</script>
</body>
</html>