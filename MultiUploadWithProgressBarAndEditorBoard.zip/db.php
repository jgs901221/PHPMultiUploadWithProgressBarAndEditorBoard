﻿<?php 
$conn = new mysqli("host이름", "mysql사용자명", "mysql암호", "DB이름");
mysqli_query ($conn, 'SET NAMES utf8');
?>