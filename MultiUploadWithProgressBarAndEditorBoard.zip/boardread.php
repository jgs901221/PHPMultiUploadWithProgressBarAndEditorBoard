﻿<!DOCTYPE html>
<html>
<?php
ob_start() ;
header("Content-Type: text/html; charset=UTF-8"); 
session_start();
?>
<head>
<title>공돌이광식</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@font-face {
font-family:"나눔바른펜 보통";
src:url("NANUMBARUNPENR.TTF") format('truetype'),
url("NANUMBARUNPENR.otf") format('opentype'),
url("NANUMBARUNPENR.woff") format('woff');
}

@font-1face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}

@font-face {
font-family:"나눔스퀘어라운드 가늘게";
src:url("NANUMSQUAREROUNDL.TTF") format('truetype'),
url("NANUMSQUAREROUNDL.otf") format('opentype'),
url("NANUMSQUAREROUNDL.woff") format('woff');
}

@font-face {
font-family:"나눔스퀘어라운드 보통";
src:url("NANUMSQUAREROUNDR.TTF") format('truetype'),
url("NANUMSQUAREROUNDR.otf") format('opentype'),
url("NANUMSQUAREROUNDR.woff") format('woff');
}

@font-face {
font-family:"나눔스퀘어라운드 굵게";
src:url("NANUMSQUAREROUNDB.TTF") format('truetype'),
url("NANUMSQUAREROUNDB.otf") format('opentype'),
url("NANUMSQUAREROUNDB.woff") format('woff');
}

@font-face {
font-family:"나눔스퀘어라운드 아주 굵게";
src:url("NANUMSQUAREROUNDEB.TTF") format('truetype'),
url("NANUMSQUAREROUNDEB.otf") format('opentype'),
url("NANUMSQUAREROUNDEB.woff") format('woff');
}

#editor {
margin-top:0;
border:1px solid black;
width:100%;
height:400px;
overflow-y:auto;
font-size:20px;
font-family:나눔스퀘어라운드 보통;
}

button {
border:none; /* button의 테두리를 없앱니다. */
}

input {
border:none; /* input의 테두리를 없앱니다. */
}

.style1 { /* style1 이라는 클래스를 지닌 요소의 스타일 속성을 지정합니다. */
width:20px; height:20px; background:none;
}

.style2 { /* style2 이라는 클래스를 지닌 요소의 스타일 속성을 지정합니다. */
width:32px; height:20px; background:none;
}

* {
    box-sizing:border-box;
}

@font-face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}

header {
    margin-top:0px;
    padding:15px;
    width:100%;
    height:100px;
    background:black;
    text-align:center;
    font-family:"나눔바른펜 굵게";
}

header a, nav a {
    text-decoration:none;
    color:white;
}

header a, nav a {
    font-size:40px;
}

nav {
    height:50px;
    width:100%;
    margin-top:10px;
    padding:10px;
    background:black;
    color:white;
    font-size:30px;
    font-family:"나눔바른펜 굵게";
}

footer {
    position: fixed;
    bottom:0;
}

div {
border:1px solid white;
}

.menu_img {
position: relative;
float:left;
width:30px;
height:30px;
background:url(nav.png) 0 0px;
border:none;
}

#contents {
display:none;
}

#contents a {
text-decoration:none;
color:black;
}

table {
width:100%;
border-collapse: collapse;
}

th {
border:1px solid;
text-align:left;
}

fieldset {
border:1px solid black;
}

@media only screen and (max-width:500px) {
img {
width:100%;
}
iframe.mp3 {
height:100px;
border:none;
}
iframe.mp4 {
width:80%;
height:300px;
border:none;
}
}

@media only screen and (min-width:500px) {
img {
width:500px;
}
iframe.mp3 {
width:500px;
height:100px;
border:none;
}
iframe.mp4 {
width:500px;
height:400px;
border:none;
}
}
</style>
</head>
<body>
<header><a href="/main.php">공돌이 광식의 홈페이지</a></header>
<nav>
<div class="menu_img" id="mic" onclick="menu_img_click()"></div>
<?php if(!isset($_SESSION['id'])){ ?>
<a href="join.html" style="float:right; margin-left:10px;">회원가입</a>
<a href="login.html" style="float:right">로그인</a>
<?php } ?>
<?php if(isset($_SESSION['id'])){ ?>
<a href="logout.php" style="float:right">로그아웃</a>
<a href="joinedit.php" style="float:right;">회원정보수정</a>
<?php } ?>
</nav>
<div id="contents" style="margin-top:0; border:1px solid; position:absolute; z-index:1; background:black;"><a href="board.php" style="color:white; font-size:20px;"><b>게시판</b></a></div>
<input type="hidden" id="c" value="">
<?php 
include 'db.php';
if(isset($_GET['x'])){
    $boardnum = $_GET['x'];
}else{
    echo "<script>location.href='/board.php'</script>"; //x값이 존재하지 않는 게시물의 값일 경우 board.php로 강제 이동
}
$cookie_name = $boardnum; //쿠키 이름은 게시판 번호로 넣어준다.
$cookie_value = "1"; //쿠기 값으로 넣어준다.
setcookie($cookie_name, $cookie_value, time() + (86400), "/"); // 1일 동안 쿠키를 유지하도록 해준다.
if(!isset($_COOKIE[$cookie_name])) { //쿠키가 삭제되지 않는 이상 조회수는 첫 조회시만 1 증가시켜준다.
    $sql2 = "UPDATE board set hit=hit+1 WHERE boardnum=$boardnum";
    $res2 = $conn->query($sql2);
}
$sql = "select *from board where boardnum='$boardnum'"; //게시판 내용 불러오기
$res = $conn->query($sql);//게시판 내용 불러오기
$row=mysqli_fetch_array($res);//게시판 내용의 배열을 저장한다.
if($res->num_rows == 0) {
    echo "<script>location.href='/board.php'</script>"; //x값을 조회한 결과 없는 게시물일 경우 board.php로 강제 이동
}
?>
<table id="title" style="width:100%; border:1px solid;"><tr><th colspan="3">제목:<?php $title=str_replace(">","&gt;",str_replace("<","&lt;",$row['boardtitle'])); echo " ".$title;?></th></tr><tr><th style="width:20%;">작성자:<?php echo " ".$row["userid"];?></th><th>작성일:<?php echo " ".$row["date"];?></th><th style="width:20%;">조회수:<?php echo " ".$row["hit"];?></th></tr></table>
<div id="editor"><?php echo str_replace("＃","#",str_replace("＝","=",str_replace("＆","&",$row["boardcontent"]))); ?></div>
<fieldset>
<legend>업로드 파일 목록</legend>
<div id="filelist" style="width:100%; height:100px; border:1px solid; overflow:auto;">
<?php 
$sql3 = "select *from boarduploadfile where starttime='".$row['starttime']."' and userid='".$row['userid']."' and type='F'"; //게시판 내용 불러오기
$res3 = $conn->query($sql3);//게시판 내용 불러오기
while($row3=mysqli_fetch_array($res3)) {
    echo "<a href='download.php?filepath=".$row3['realname']."&filename=".$row3['fakename']."'>".$row3['fakename']."</a><br>";
}
?>
</div>
</fieldset>
<div>
<?php 
if(isset($_SESSION['id']))
{
if(($_SESSION['id']==$row["userid"]) && ($_SESSION['username']==$row["username"])) 
{
    echo "<button style='float:right; border:1px solid; background:none;' onclick=\"location.href='/boarddelete.php?x=$boardnum'\">삭제하기</button>";	
    echo "<button style='float:right; border:1px solid; background:none;' onclick=\"location.href='/boardupdate.php?x=$boardnum'\">수정하기</button>";
}
} ?>
</div>
<?php if(isset($_SESSION['id'])) { ?>
<!-- 댓글을 작성하는 곳 -->
<form id="reply1applyid" action="reply1apply.php" method="post" target="reply1">
<fieldset style="margin-top:20px;">
<legend>댓글 작성란</legend>
<input type="hidden" name="reply1boardnum" value="<?php echo $boardnum; ?>">
<input type="hidden" name="reply1userid" value="<?php echo $_SESSION['id']; ?>">
<input type="hidden" name="reply1time" value="<?php echo time(); ?>">
<textarea id="reply1textarea" type="text" name="reply1textarea" style="width:100%; height:100px; border:1px solid; resize:none;"></textarea>
<input type="submit" style='float:right; border:1px solid; background:none;' value="댓글 등록">
</fieldset>
</form>
<?php } ?>
<iframe name="reply1" style="display:none;"></iframe>
<fieldset style="margin-top:20px;">
<legend>댓글 보기</legend>
<div id="replys" style="border:1px solid; height:400px; overflow:auto;">
<?php

$sql8="SELECT * FROM reply WHERE boardnum=$boardnum and replynum2=0 and replytrue=0 ORDER BY reply.replynum DESC LIMIT 5";
$res8 = $conn->query($sql8);
$savenum="0";
$count="0";
while($row8=mysqli_fetch_array($res8,MYSQLI_NUM)) {
$count++;
if($count==5){
if($savenum=="0") {
$savenum=$row8[1];
}
}
}
$sql4="SELECT * FROM reply WHERE boardnum=$boardnum and replynum2=0 and replytrue=0 ORDER BY reply.replynum DESC LIMIT 5";
$res4 = $conn->query($sql4);
while($row4=mysqli_fetch_array($res4)) {
echo "<div id=\"reply1show".$row4['replynum']."\">".$row4['userid']." ".date('y년 m월 d일 h시 i분 s초',$row4['starttime'])."<br>
<span id=\"reply1text".$row4['replynum']."\">".str_replace("<","&lt",$row4['replycontents'])."</span><br>";
$sql7="select *from reply where boardnum=$boardnum and replynum=".$row4['replynum']." and replynum2>0";
$res7 = $conn->query($sql7);
if(isset($_SESSION['id'])) {
if($res7->num_rows == 0) {
//답글 작성란을 불러온다.
echo "<button id='replyboxshow".$row4['replynum']."second' onclick='replyboxshow(".$row4['replynum'].")'>답글</button>";
}
if($res7->num_rows != 0) {
echo "<button id='replyboxshow".$row4['replynum']."second' onclick='replyboxshow(".$row4['replynum'].")' style='display:none;'>답글</button>";
//버튼 숨킴. 답글 더보기 버튼 숨킴. 답글 목록 불러옴. 답글 작성란을 불러옴.
echo "<button id='replyboxshow".$row4['replynum']."first' onclick=\"this.style.display='none'; document.getElementById('replyboxshow".$row4['replynum']."second').style.display='inline-block'; document.getElementById('reply2show".$row4['replynum']."resultshow').style.display='inline-block'; document.getElementById('reply2show".$row4['replynum']."resultmore').style.display='none'; replyboxshow(".$row4['replynum']."); reply2show".$row4['replynum'].".submit();\">답글</button>";
}
if($_SESSION['id'] == $row4['userid']) {
echo "<button onclick='reply1update(".$row4['replynum'].")'>수정</button>";
echo "<button onclick='reply1delete(".$row4['replynum']."); reply1deleteformid".$row4['replynum'].".submit();'>삭제 </button>";
echo "<form id='reply1deleteformid".$row4['replynum']."' action='reply1delete.php' method='post' target='reply1'>";
//게시물 번호 전송
echo "<input type='hidden' name='reply1deleteboardnum' value='".$boardnum."'>";
//댓글 번호 전송
echo "<input type='hidden' name='reply1deletereplynum' value='".$row4['replynum']."'>";
echo "</form>";
}
}
$sql6="SELECT * FROM reply WHERE boardnum=$boardnum and replynum=".$row4['replynum']." ORDER BY reply.replynum2 DESC";
$res6 = $conn->query($sql6);
$count=0;
while($row6=mysqli_fetch_array($res6)) {
if($row6['replynum2'] != 0) {
$count++;
}
}
//수정 필요
if($count > 0) {
//1. 답글 더보기 버튼을 숨겨준다. 2. 답글을 불러온다. 3. 답글 숨기기 버튼이 나타나도록 만든다.
echo "<button id='reply2show".$row4['replynum']."resultmore' onclick=\"this.style.display='none'; document.getElementById('replyboxshow".$row4['replynum']."first').style.display='none'; document.getElementById('replyboxshow".$row4['replynum']."second').style.display='inline-block'; reply2show".$row4['replynum'].".submit(); document.getElementById('show".$row4['replynum']."').style.display='block'; document.getElementById('reply2show".$row4['replynum']."resulthide').style.display='inline-block';\">답글 "."$count"."개 보기</button>";
//1. 답글 숨기기 버튼을 숨겨준다. 2. 불러온 답글을 숨겨준다. 3. 답글 더보기 버튼을 다시 나타내준다.(기존에 불러온 답글 내용만 나타나게 해줄 것이다.) reply2show".$row4['replynum']."resultshow
echo "<button id='reply2show".$row4['replynum']."resulthide' onclick=\"this.style.display='none'; document.getElementById('show".$row4['replynum']."').style.display='none'; document.getElementById('reply2show".$row4['replynum']."resultshow').style.display='inline-block';\" style='display:none;'>답글 숨기기</button>";
//1. 답글 더보기 버튼을 숨겨준다. 2. 불러온 답글을 보여준다. 3. 답글 숨기기 버튼을 보여준다.
echo "<button id='reply2show".$row4['replynum']."resultshow' onclick=\"this.style.display='none'; document.getElementById('show".$row4['replynum']."').style.display='block'; document.getElementById('reply2show".$row4['replynum']."resulthide').style.display='inline-block';\" style='display:none;'>답글 "."$count"."개 보기</button>";
}
echo "<form id='reply2show".$row4['replynum']."' action='reply2show.php' method='post' target='reply1'>";
//게시물 번호 전송
echo "<input type='hidden' name='reply2boardnum' value='".$boardnum."'>";
//댓글 번호 전송
echo "<input type='hidden' name='reply2replynum' value='".$row4['replynum']."'>";
//등록 취소 혹은 등록
echo "</form>";
if(isset($_SESSION['id'])) {
//자식 댓글 달기
//자식 댓글을 달면, reply2apply.php 파일에 post방식으로 값을 전달하되,
//reply1이라는 이름의 iframe에 reply2apply.php파일의 결과물이 출력되도록 만든다.
echo "<fieldset id='reply2applyid".$row4['replynum']."' style='margin-top:20px; display:none;'>";
echo "<legend>댓글 작성란</legend>";
//게시물 번호 전송
echo "<form id='reply2formid".$row4['replynum']."' action='reply2apply.php' method='post' target='reply1'>";
echo "<input type='hidden' name='reply2boardnum' value='".$boardnum."'>";
//댓글 번호 전송
echo "<input type='hidden' name='reply2replynum' value='".$row4['replynum']."'>";
//유저 이름 전송
echo "<input type='hidden' name='reply2userid' value='".$_SESSION['id']."'>";
//등록 시간 전송
echo "<input type='hidden' name='reply2time' value='".time()."'>";
//텍스트 전송
echo "<textarea type='text' name='reply2textarea' style='width:100%; height:100px; border:1px solid; resize:none;'></textarea>";
//등록 취소 혹은 등록
echo "</form>";
echo "<button style='float:right; border:1px solid; background:none;' onclick='reply2cancel(".$row4['replynum'].")'>취소</button><button style='float:right; border:1px solid; background:none;' onclick=\"reply2formid".$row4['replynum'].".submit();\">댓글 등록</button>";
echo "</fieldset>";
}
if(isset($_SESSION['id'])) {
if($_SESSION['id'] == $row4['userid']) {
//댓글1 수정
echo "<fieldset id='reply1updateid".$row4['replynum']."' style='margin-top:20px; display:none;'>";
echo "<legend>댓글 수정란</legend>";
echo "<form id='reply1updateformid".$row4['replynum']."' action='reply1update.php' method='post' target='reply1'>";
//게시물 번호 전송
echo "<input type='hidden' name='reply1updateboardnum' value='".$boardnum."'>";
//댓글 번호 전송
echo "<input type='hidden' name='reply1updatereplynum' value='".$row4['replynum']."'>";
//텍스트 전송
echo "<textarea type='text' name='reply1updatetextarea' style='width:100%; height:100px; border:1px solid; resize:none;'>".str_replace("<","&lt",$row4['replycontents'])."</textarea>";
//등록 취소 혹은 등록
echo "</form>";
echo "<button style='float:right; border:1px solid; background:none;' onclick='reply1updatecancel(".$row4['replynum'].")'>취소</button><button style='float:right; border:1px solid; background:none;' onclick='reply1updateformid".$row4['replynum'].".submit()'>댓글 수정</button>";
echo "</fieldset>";
}
}
echo "<br><br>";
if($res7->num_rows == 0) {
echo "<div id='show".$row4['replynum']."' style='margin-left:10%; margin-right:10%;'></div>";
}
if($res7->num_rows != 0) {
echo "<div id='show".$row4['replynum']."' style='display:none; margin-left:10%; margin-right:10%;'></div>";
}
echo "</div>";
}
//더보기
$sql5="SELECT * FROM reply WHERE boardnum=$boardnum and replynum2=0 and replytrue=0 ORDER BY reply.replynum DESC";
$res5 = $conn->query($sql5);
if($res5->num_rows > 5) {
echo "<p id='rcb' style='text-align:center;' onclick=\"this.style.display='none';+reply1limitfunction($savenum)&reply1moreid.submit()\">더보기</p>";
}
?>
</div>
</fieldset>

<form id="reply1moreid" action="reply1more.php" method="post" target="reply1m">
<input type="hidden" name="reply1boardnum" value="<?php echo $boardnum; ?>">
<input type="hidden" id="reply1replynumid" name="reply1replynum">
<input type="hidden" id="reply1limit" name="reply1limit">
</form>
<iframe name="reply1m" style="display:none;"></iframe>

<form id="reply2moreid" action="reply2more.php" method="post" target="reply2m">
<input type="hidden" name="reply2boardnum" value="<?php echo $boardnum; ?>">
<input type="hidden" id="reply2replynumid" name="reply2replynum">
<input type="hidden" id="reply2replynumid2" name="reply2replynum2">
<input type="hidden" id="reply2limit" name="reply2limit">
</form>
<iframe name="reply2m" style="display:none;"></iframe>
<footer>&copy; 2019 by 공돌이광식</footer>
<script>
r1l=0;
//부모 댓글창 수
function reply1limitfunction(r1rni) {
r1l=r1l+5;
document.getElementById("reply1limit").value = r1l;
document.getElementById("reply1replynumid").value = r1rni;
}

r2l=0;
//자식 댓글창 수
function reply2limitfunction(r2rni,r2rni2) {
r2l=r2l+5;
document.getElementById("reply2limit").value = r2l;
document.getElementById("reply2replynumid").value = r2rni;
document.getElementById("reply2replynumid2").value = r2rni2;
}

//자식 댓글창이 열리거나 닫히도록 만듦.
var rn=0;
function replyboxshow(rbs) {
if(rn != 0) {
document.getElementById('reply2applyid'+rn).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
if(rn2 != 0) {
document.getElementById('reply2update'+rn1+'id'+rn2).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
if(rn1 != 0) {
document.getElementById('reply1updateid'+rn1).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
document.getElementById('reply2applyid'+rbs).style.display = 'block';
rn=rbs;
}

var rn1=0;
function reply1update(rbs1) {
//답글 작성란 항목을 감추어준다.
if(rn != 0) {
document.getElementById('reply2applyid'+rn).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
if(rn2 != 0) {
document.getElementById('reply2update'+rn1+'id'+rn2).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란 항목을 감추어준다.
if(rn1 != 0) {
document.getElementById('reply1updateid'+rn1).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란 항목을 나타나도록 만들어준다.
document.getElementById('reply1updateid'+rbs1).style.display = 'block';
rn1=rbs1;
}

var rn2=0;
function reply2update(rbs1,rbs2) {
//답글 작성란 항목을 감추어준다.
if(rn != 0) {
document.getElementById('reply2applyid'+rn).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란2 항목을 감추어준다.
if(rn2 != 0) {
document.getElementById('reply2update'+rn1+'id'+rn2).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란 항목을 감추어준다.
if(rn1 != 0) {
document.getElementById('reply1updateid'+rn1).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란2 항목을 나타내어 준다.
document.getElementById('reply2update'+rbs1+'id'+rbs2).style.display = 'block';
rn1=rbs1;
rn2=rbs2;
}

//자식 댓글 수정창 닫기
function reply2updatecancel(rbs1,rbs2) {
document.getElementById('reply2update'+rbs1+'id'+rbs2).style.display = 'none';
}

//자식 댓글창 닫기
function reply2cancel(rbs) {
document.getElementById('reply2applyid'+rbs).style.display = 'none';
}

//부모 댓글 수정창 닫기
function reply1updatecancel(rbs1) {
document.getElementById('reply1updateid'+rbs1).style.display = 'none';
}

function reply1delete(rbs1) {
//답글 작성란 항목을 감추어준다.
if(rn != 0) {
document.getElementById('reply2applyid'+rn).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
if(rn2 != 0) {
document.getElementById('reply2update'+rn1+'id'+rn2).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란 항목을 감추어준다.
if(rn1 != 0) {
document.getElementById('reply1updateid'+rn1).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
}

function reply2delete(rbs1,rbs2) {
//답글 작성란 항목을 감추어준다.
if(rn != 0) {
document.getElementById('reply2applyid'+rn).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
if(rn2 != 0) {
document.getElementById('reply2update'+rn1+'id'+rn2).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
//답글 수정란 항목을 감추어준다.
if(rn1 != 0) {
document.getElementById('reply1updateid'+rn1).style.display = 'none';
rn=0;
rn1=0;
rn2=0;
}
}

//에디터 안에 쓰여진 값들 중 특수문자들에 대해 고쳐준다.
document.getElementById("editor").innerHTML = document.getElementById("editor").innerHTML.replace("＋","+").replace(/＃/g,"#").replace(/＝/g,"=").replace(/＼/g,"\\");

//세줄 이미지 클릭시 게시판으로 들어갈 수 있는 링크가 보이고, X 버튼 클릭시 링크가 감추어진다.
function menu_img_click() {
	x=document.getElementById('c');
	x3=document.getElementById('contents');
	x2=document.getElementById('mic');
	if (x.value == "") {
		x2.style.background = 'url(nav.png) 0 30px';
	    x3.style.display = "block";
	    x.value="1";
	  } else {
		x2.style.background = 'url(nav.png) 0 0';
	    x3.style.display = "none";
	    x.value="";
	  }
	}
</script>
</body>
</html>