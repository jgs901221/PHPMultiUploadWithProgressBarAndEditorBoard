﻿<?php header("Content-Type: text/html; charset=UTF-8"); 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>공돌이광식</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css">
* {
    box-sizing:border-box;
}
@font-face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}

#boardimg {
width:100%;
}

header {
    margin-top:0px;
    padding:15px;
    width:100%;
    height:100px;
    background:black;
    text-align:center;
    font-family:"나눔바른펜 굵게";
}
a {
    text-decoration:none;
    color:black;
    }
header a, nav a {
    text-decoration:none;
    color:white;
}
@media only screen and (min-width:230px) { /* 창의 최소 너비 0px부터 */
	header a, nav a {
    font-size:40px;
}
nav {
height:50px;
}
}
@media only screen and (max-width:230px) and (min-width:0px) { /* 창의 최소 너비 0px부터 */
	header a, nav a {
    font-size:30px;
}
nav {
height:100px;
}
}
nav {
    width:100%;
    margin-top:10px;
    padding:10px;
    background:black;
    color:white;
    font-size:30px;
    font-family:"나눔바른펜 굵게";
}
footer {
    position: fixed;
    bottom:0;
}
div {
border:1px solid white;
}
.menu_img {
position: relative;
float:left;
width:30px;
height:30px;
background:url(nav.png) 0 0px;
border:none;
}
#contents {
display:none;
}
#contents a {
text-decoration:none;
color:black;
}
table {
width:100%;
}
table,th,td {
border:1px solid;
border-collapse: collapse;
}
.center {
  text-align: center;
  margin-top:10px;
}
.pagination {
  display: inline-block;
}
.pagination a {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  border: 1px solid #ddd;
}
.pagination a.active {
  background-color: #4CAF50;
  color: white;
  border: 1px solid #4CAF50;
}

.pagination a:hover:not(.active) {background-color: #ddd;}

.pagination a:first-child {
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
}

.pagination a:last-child {
  border-top-right-radius: 5px;
  border-bottom-right-radius: 5px;
}
</style>
</head>
<body>
<header><a href="/main.php">공돌이 광식의 홈페이지</a></header>
<nav>
<?php include 'db.php';
//현재 페이지
if(isset($_GET['page'])){
    $page = $_GET['page'];
}else{
    $page = 1;
}
//현재 블록번호
if(isset($_GET['pagination'])){
    $pagination = $_GET['pagination'];
}else{
    $pagination = 1;
}
$sql = "select *from board";
$res = $conn->query($sql);
$totalboardnum = mysqli_num_rows($res); //총 게시물 수
$totalpagenum = ceil($totalboardnum/10); //총 페이지 수 = 총 게시물 수 / 한 페이지당 나타낼 게시물 수
$totalblocknum = ceil($totalpagenum/5); //총 블록 수 = 총 페이지 수 / 한 블록에 나타낼 페이지 수
$currentpagenum = (($page-1)*10); //현재 페이지 번호 = (페이지 번호-1)*3
$sql2 = "select *from board order by boardnum asc limit $currentpagenum,10";
$res2 = $conn->query($sql2);
$num2=(($page-1)*10)+1;
?>
<div class="menu_img" id="mic" onclick="menu_img_click()"></div>
<?php if(!isset($_SESSION['id'])){ ?>
<a href="join.html" style="float:right; margin-left:10px;">회원가입</a>
<a href="login.html" style="float:right">로그인</a>
<?php } ?>
<?php if(isset($_SESSION['id'])){ ?>
<a href="logout.php" style="float:right;">로그아웃</a>
<a href="joinedit.php" style="float:right;">회원정보수정</a>
<?php } ?>
</nav>
<div id="contents" style="margin-top:0; border:1px solid; position:absolute; z-index:1; background:black;"><a href="board.php" style="color:white; font-size:20px;"><b>게시판</b></a></div>
<input type="hidden" id="c" value="">
<div><table><tr><th>번호</th><th>제목</th><th>작성자</th><th>작성일</th><th>조회수</th></tr>
<?php while ($row=mysqli_fetch_array($res2)) { $num=$row['boardnum'];
$title=str_replace(">","&gt;",str_replace("<","&lt;",str_replace($row['boardtitle'], mb_substr($row['boardtitle'],0,40,"utf-8")."...",$row['boardtitle'])));
$title2=str_replace(">","&gt;",str_replace("<","&lt;",$row['boardtitle']));
?>
<tr style = "cursor:pointer;" onClick = "location.href='/boardread.php?x=<?php echo $num;?>'"><th><?php echo $num2;?></th><th><?php if(mb_strlen($row['boardtitle'],"utf-8") > 30) {echo $title;} else {echo $title2;}?></th><th><?php echo $row['userid'];?></th><th><?php echo mb_substr($row['date'],0,11,"utf-8");?></th><th><?php echo $row['hit'];?></th></tr>
<?php $num2++;}?>
</table>
</div> 
<div class="center">
<div class="pagination">
<?php 
$before=$pagination-1; //현재 블록 위치 -1
$after=$pagination+1; //현재 블
$before2=$before*5; //변동 요망
$after2=$after*5-4;
if($pagination>1)
{
    echo "<a href='/board.php?pagination=$before&page=$before2'>&laquo;</a>";
}
for($i=$pagination*5-4; $i<=$pagination*5; $i++)
{
    if($i<=$totalpagenum) {
    echo "<a href='/board.php?pagination=$pagination&page=$i'>[$i]</a>";
    } else {
        break;
    }
}
if($pagination<$totalblocknum) {
    echo "<a href='/board.php?pagination=$after&page=$after2'>&raquo;</a>";
}
?>
</div>
<?php if((isset($_SESSION['id']) && isset($_SESSION['username']))) { ?>
    <button style="position:absolute; right:10px; border:1px solid; background:none;" onclick="location.href='/boardwrite.php?clicktime=<?php echo time(); ?>'">게시글 작성하기</button>
<?php } ?>
</div>
<footer>&copy; 2019 by 공돌이광식</footer>
<script type="text/javascript">
function menu_img_click() {
	x=document.getElementById('c');
	x3=document.getElementById('contents');
	x2=document.getElementById('mic');
	if (x.value == "") {
		x2.style.background = 'url(nav.png) 0 30px';
	    x3.style.display = "block";
	    x.value="1";
	  } else {
		x2.style.background = 'url(nav.png) 0 0';
	    x3.style.display = "none";
	    x.value="";
	  }
	}
</script>
</body>
</html>