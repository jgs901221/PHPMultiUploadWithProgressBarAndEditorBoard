﻿<?php 
//text 및 html 유형 utf-8로 인코딩
header("Content-Type: text/html; charset=UTF-8"); 
//세션 시작
session_start();
//세션에 저장된 아이디 및 이름 값이 없다면, 게시판 페이지로 이동
if(!(isset($_SESSION['id']) && isset($_SESSION['username']))) { 
echo "<script>location.href='board.php';</script>";
}
?>
<!DOCTYPE html><!-- html5로 작성된 문서임을 알림 -->
<html><!-- html 태그 시작 -->
<head><!-- head 태그 시작 -->
<title>공돌이광식</title><!-- 페이지 제목 -->
<meta charset="UTF-8" /><!-- utf-8로 인코딩 -->
<meta http-equiv="X-UA-Compatible" content="IE=Edge"><!-- 호환성 설정. IE8이상 버전에 대해 최신 표준 모드로 렌더링. 크롬에 대해 IE11로 렌더링 -->
<meta name="viewport" content="width=device-width, initial-scale=1"><!-- 가상 뷰포트의 너비를 장치의 가상 뷰포트의 너비로 설정. 축적 비율 1:1 -->
<style type="text/css">/* 스타일 태그 시작 */
/* img태그 요소의 최대 너비는 100% */
img {
max-width:100%;
}
/* mp3클래스를 적용한 iframe태그 요소의 최대 너비는 100% */
iframe.mp3 {
max-width:100%;
}
/* mp4클래스를 적용한 iframe태그 요소의 최대 너비는 100% */
iframe.mp4 {
max-width:100%;
}
/* jl아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 j.png이미지의 위치는 (0,0), 왼쪽 유동 */
#jl {
	width : 20px;
	height : 20px;
	background: url("j.png") 0 0;
	float:left;
}
/* jc아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 j.png이미지의 위치는 (-20px,0), 왼쪽 유동 */
#jc {
	width : 20px;
	height : 20px;
	background: url("j.png") -20px 0;
	float:left;
}
/* jr아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 j.png이미지의 위치는 (-40px,0), 왼쪽 유동 */
#jr {
	width : 20px;
	height : 20px;
	background: url("j.png") -40px 0;
	float:left;
}
/* jf아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 j.png이미지의 위치는 (-60px,0), 왼쪽 유동 */
#jf {
	width : 20px;
	height : 20px;
	background: url("j.png") -60px 0;
	float:left;
}
/* io아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 i.png이미지의 위치는 (0,0), 왼쪽 유동 */
#io {
	width : 20px;
	height : 20px;
	background: url("i.png") 0 0;
	float:left;
}
/* iu아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 i.png이미지의 위치는 (-20px,0), 왼쪽 유동 */
#iu {
	width : 20px;
	height : 20px;
	background: url("i.png") -20px 0;
	float:left;
}
/* id아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 i.png이미지의 위치는 (-40px,0), 왼쪽 유동 */
#id {
	width : 20px;
	height : 20px;
	background: url("i.png") -40px 0;
	float:left;
}
/* od아이디가 적용된 요소의 너비는 20px, 높이는 20px, 배치된 i.png이미지의 위치는 (-60px,0), 왼쪽 유동 */
#od {
	width : 20px;
	height : 20px;
    	background: url("i.png") -60px 0;
    	float:left;
}
/* 외부 폰트 추가 */
@font-face {
font-family:"나눔바른펜 보통";
src:url("NANUMBARUNPENR.TTF") format('truetype'),
url("NANUMBARUNPENR.otf") format('opentype'),
url("NANUMBARUNPENR.woff") format('woff');
}
@font-face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}
@font-face {
font-family:"나눔스퀘어라운드 가늘게";
src:url("NANUMSQUAREROUNDL.TTF") format('truetype'),
url("NANUMSQUAREROUNDL.otf") format('opentype'),
url("NANUMSQUAREROUNDL.woff") format('woff');
}
@font-face {
font-family:"나눔스퀘어라운드 보통";
src:url("NANUMSQUAREROUNDR.TTF") format('truetype'),
url("NANUMSQUAREROUNDR.otf") format('opentype'),
url("NANUMSQUAREROUNDR.woff") format('woff');
}
@font-face {
font-family:"나눔스퀘어라운드 굵게";
src:url("NANUMSQUAREROUNDB.TTF") format('truetype'),
url("NANUMSQUAREROUNDB.otf") format('opentype'),
url("NANUMSQUAREROUNDB.woff") format('woff');
}
@font-face {
font-family:"나눔스퀘어라운드 아주 굵게";
src:url("NANUMSQUAREROUNDEB.TTF") format('truetype'),
url("NANUMSQUAREROUNDEB.otf") format('opentype'),
url("NANUMSQUAREROUNDEB.woff") format('woff');
}
/* editor아이디가 적용된 요소의 윗여백은 0, 테두리는 1px 검정 실선, 폭 100%, 높이 400px, 
자동 스크롤바 생성 기능, 폰트 크기 20px, 글꼴 지정 */
#editor {
margin-top:0;
border:1px solid black;
width:100%;
height:400px;
overflow:auto;
font-size:20px;
font-family:나눔스퀘어라운드 보통;
}
/* button 요소의 테두리를 없앤다. */
button {
border:none;
}
/* input 요소의 테두리를 없앤다. */
input {
border:none;
}
/* style1 클래스를 사용하는 요소의 너비와 높이는 각각 20px, 배경 없음, 왼쪽 유동 */
.style1 {
width:20px; height:20px; background:none;
float:left;
}
/* style2 클래스를 사용하는 요소의 너비는 32px, 높이는 20px, 배경 없음, 왼쪽 유동 */
.style2 {
width:32px; height:20px; background:none;
float:left;
}
/* 모든 태그에 대해서 테두리 상자를 포함해서 상자 크기가 변경되도록 설정 */
* {
    box-sizing:border-box;
}
/* header의 요소에 대해서 윗 여백 0px, 안쪽 여백 15px, 너비 100%, 높이 100px,
배경 검정, 텍스트 가운데 정렬, 글꼴 적용 */
header {
    margin-top:0px;
    padding:15px;
    width:100%;
    height:100px;
    background:black;
    text-align:center;
    font-family:"나눔바른펜 굵게";
}
/* header 요소 안에 이는 a요소 및 nav 요소 안에 있는 a요소에 대해서 밑줄 없앰, 흰색 부여 */
header a, nav a {
    text-decoration:none;
    color:white;
}
/* 창의 최소 너비가 230px 이상일 경우 header 및 nav 요소 안에 이는 a요소에 대해 폰트 크기 40px,
nav 요소의 높이 50px */
@media only screen and (min-width:230px) {
	header a, nav a {
    font-size:40px;
}
nav {
height:50px;
}
}
/* 창의 최소 너비 0px부터 최대 230px까지 */
@media only screen and (max-width:230px) and (min-width:0px) {
/* header 및 nav 요소 안 a태그의 폰트 크기 30px */
header a, nav a {
    font-size:30px;
}
/* nav 요소의 높이는 100px */
nav {
height:100px;
}
}
/* nav 요소의 높이 100px, 너비 100%, 윗 여백 10px, 안쪽 여백 10px, 배경 검정, 색상 흰색,
폰트 크기 30px, 글꼴 지정 */
nav {
    width:100%;
    margin-top:10px;
    padding:10px;
    background:black;
    color:white;
    font-size:30px;
    font-family:"나눔바른펜 굵게";
}
/* footer 요소의 위치는 아래에 고정 */
footer {
    position: fixed;
    bottom:0;
}
div {
border:1px solid white;
}
.menu_img {
position: relative;
float:left;
width:30px;
height:30px;
background:url(nav.png) 0 0px;
border:none;
}
#contents {
display:none;
}
#contents a {
text-decoration:none;
color:black;
}
table {
width:100%;
}
fieldset {
border:1px solid black;
}
progress {
border:1px solid;
border-radius:5px;
height:10px;
color:lightgreen;
}
</style>
</head>
<body>
<header><a href="/main.php">공돌이 광식의 홈페이지</a>
<div style="position:absolute; top:10px; left:10px; border:none; background:white; color:black;">
  <h3 id="status1"></h3>
  <p id="loaded_n_total1"></p>
  <progress id="progressBar1" value="0" max="100" style="display:none; width:300px;"></progress>
</div>
</header>
<nav>
<div class="menu_img" id="mic" onclick="menu_img_click()"></div>
<?php if(!isset($_SESSION['id'])){ ?>
<a href="join.html" style="float:right; margin-left:10px;">회원가입</a>
<a href="login.html" style="float:right">로그인</a>
<?php } ?>
<?php if(isset($_SESSION['id'])){ ?>
<a href="logout.php" style="float:right">로그아웃</a>
<a href="joinedit.php" style="float:right;">회원정보수정</a>
<?php } ?>
</nav>
<div id="contents" style="margin-top:0; border:1px solid; position:absolute; z-index:1; background:black;"><a href="board.php" style="color:white; font-size:20px;"><b>게시판</b></a></div>
<input type="hidden" id="c" value="">
<textarea id="title" style="border:1px solid; width:100%; resize:none;" placeholder="제목을 작성하세요. 300자 이내" maxLength = "300"></textarea>
<fieldset style=" margin:0; padding:0;">
<legend>도구 모음</legend>
<span style="position:relative; float:left;">
<select style="border:none; width:130px; height:20px;" onchange="fontName(this.value)" title="선택한 영역의 글꼴을 변경합니다.">
  <option value="나눔바른펜 보통">나눔바른펜 보통</option>
  <option value="나눔바른펜 굵게">나눔바른펜 굵게</option>
  <option value="나눔스퀘어라운드 가늘게">나눔스퀘어라운드 가늘게</option>
  <option value="나눔스퀘어라운드 보통" selected>나눔스퀘어라운드 보통</option>
  <option value="나눔스퀘어라운드 굵게">나눔스퀘어라운드 굵게</option>
  <option value="나눔스퀘어라운드 아주 굵게">나눔스퀘어라운드 아주 굵게</option>
</select>
</span>
<span style="position:relative; float:left;">
<select id="choice" style="border:none; width:80px; height:20px;" onchange="fontSize(this.value)" title="선택한 영역의 글꼴 크기를 변경합니다.">
  <option value="1">매우 작음</option>
  <option value="2">작음</option>
  <option value="3">조금 작음</option>
  <option value="4" selected>보통</option>
  <option value="5">조금 큼</option>
  <option value="6">큼</option>
  <option value="7">매우 큼</option>
</select>
</span>
<button onclick="bold()" class="po1 style1" title="선택한 영역의 글꼴을 굵게 만듭니다."><b>B</b></button> 
<button onclick="italic()" class="po1 style1" title="선택한 영역의 글꼴을 이탤릭체로 만듭니다."><i>I</i></button>
<button onclick="underline()" class="style1" style="text-decoration: underline;" title="선택한 영역의 글꼴에 밑줄을 긋습니다.">U</button>
<button onclick="Strikethrough()" class="style1" style="text-decoration: line-through;" title="선택한 영역의 글꼴에 취소선을 긋습니다.">S</button>
<button onclick="sub()" class="style2" title="선택한 영역의 글꼴을 아래 첨자로 만듭니다.">T<sub>sub</sub></button>
<button onclick="sup()" class="style2" title="선택한 영역의 글꼴을 위 첨자로 만듭니다.">T<sup>sup</sup></button>
<input type="color" style="float:left; width:20px; height:20px; background:none;" title="선택한  영역의 글꼴의 색상을 변경합니다." onchange="fontColor(this.value)">
<input type="button" onclick="justifyleft()" id="jl" width="1" height="1" title="선택한  영역의 글꼴을 왼쪽으로 정렬합니다.">
<input type="button" onclick="justifycenter()" id="jc" width="1" height="1" title="선택한  영역의 글꼴을 가운데로 정렬합니다.">
<input type="button" onclick="justifyright()" id="jr" width="1" height="1" title="선택한  영역의 글꼴을 오른쪽으로 정렬합니다.">
<input type="button" onclick="justifyfull()" id="jf" width="1" height="1" title="선택한  영역의 글꼴을 양쪽으로 정렬합니다.">
<input type="button" onclick="insertOrderedList()" id="io" width="1" height="1" title="선택한  영역의 글꼴에 번호를 매깁니다.">
<input type="button" onclick="insertUnorderedList()" id="iu" width="1" height="1" title="선택한  영역의 글꼴에 bullet을 매깁니다.">
<input type="button" onclick="outdent()" id="od" width="1" height="1" title="선택한  영역의 글꼴을 내어쓰기합니다.">
<input type="button" onclick="indent()" id="id" width="1" height="1" title="선택한  영역의 글꼴을 들여쓰기합니다.">
<!--
<form action="upload.php" style="float:left; position:relative; width:20px; height:20px;" method="post" enctype="multipart/form-data">
    <input type="file" style="width:20px; height:20px; opacity:0;" name="fileToUpload[]" multiple="multiple" title="이미지 파일을 삽입합니다." onchange="this.form.submit()">
    <div style="width:20px; height:20px; background:url('ib.png'); position:absolute; z-index:-1; top:0;"></div>
    <input type="hidden" style="width:20px; height:20px;" name="userid" value="<?php echo $_SESSION['id']; ?>">
    <input type="hidden" style="width:20px; height:20px;" name="time" value="<?php echo $_GET['clicktime']; ?>">
</form>
-->
<form style="float:left; position:relative; width:20px; height:20px;" enctype="multipart/form-data" method="post">
  <input type="file"  style="width:20px; height:20px; opacity:0;" name="file1" id="file1" multiple="multiple" title="문단 맨 마지막에 미디어 파일(mp3/mp4 300MB 이내/이미지 10MB이내)을 삽입합니다." onchange="upload()"><br> 
  <div style="width:20px; height:20px; background:url('ib.png'); position:absolute; z-index:-1; top:0;"></div>
</form>
<form style="float:left; position:relative; width:20px; height:20px;" enctype="multipart/form-data" method="post">
  <input type="file"  style="width:20px; height:20px; opacity:0;" name="file2" id="file2" multiple="multiple" title="zip 또는 egg 확장자를 지닌 파일을 첨부합니다." onchange="upload2()"><br> 
  <div style="width:20px; height:20px; background:url('f.png'); position:absolute; z-index:-1; top:0;"></div>  
</form>
<script>
function upload() {
//upload함수 실행

function _(id){
//document.getElementById를 
	return document.getElementById(id);
}
var num = 0;
var file = _("file1").files[num];
if(file == null) {
return false;
}
var a = "loaded_n_total1"; 
var b = "progressBar1";
var c = "status1";
document.getElementById("file1").disabled = true;
document.getElementById("file2").disabled = true;
uploadFile(file);
function uploadFile(file){
	_(b).style.display = "block";
	var formdata = new FormData();
	formdata.append("file1", file);
	formdata.append("userid", "<?php echo $_SESSION['id']; ?>");
	formdata.append("starttime", "<?php echo $_GET['clicktime']; ?>");
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler, false);
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "upload.php");
	ajax.send(formdata);
}
function progressHandler(event){
	_(a).innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_(b).value = Math.round(percent);
	_(c).innerHTML = (num+1)+"번째 파일이"+Math.round(percent)+"% 업로드 중입니다."+"업로드 대기 중인 파일은 "+(_("file1").files.length-(num+1))+"개 입니다.";
}
function completeHandler(event){
	_(b).style.display = "none";
	if(event.target.responseText != "업로드 실패"
	&&event.target.responseText != "선택한 파일이 없습니다."
	&&event.target.responseText != "업로드 할 수 없는 형식의 파일입니다."
	&&event.target.responseText != "첨부할 수 있는 최대 용량은 10MB입니다."
	&&event.target.responseText != "첨부할 수 있는 최대 용량은 300MB입니다.") {
	document.getElementById("editor").focus();
	_("editor").innerHTML += event.target.responseText;
	document.getElementById("editor").focus();
	}
	_(b).value = 0;
	num++;
	file = _("file1").files[num];
	if(num< _("file1").files.length) {
	uploadFile(file);
	}
	if(num == _("file1").files.length) {
	if(event.target.responseText == "업로드 실패"
	||event.target.responseText == "선택한 파일이 없습니다."
	||event.target.responseText == "업로드 할 수 없는 형식의 파일입니다."
	||event.target.responseText == "첨부할 수 있는 최대 용량은 10MB입니다."
	||event.target.responseText == "첨부할 수 있는 최대 용량은 300MB입니다.") {
	alert(event.target.responseText);
	} else {
	alert("업로드 성공!");
	}
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_("file1").disabled = false;
	_("file2").disabled = false;
	}
}
function errorHandler(event){
	alert("업로드를 실패하였습니다!");
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_(b).style.display = "none";
	_("file1").disabled = false;
	_("file2").disabled = false;
}
function abortHandler(event){
	alert("업로드가 중단되었습니다!");
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_(b).style.display = "none";
	_("file1").disabled = false;
	_("file2").disabled = false;
}
}

function upload2() {
//upload함수 실행

function _(id){
//document.getElementById를 
	return document.getElementById(id);
}
var num = 0;
var file = _("file2").files[num];
if(file == null) {
return false;
}
var a = "loaded_n_total1"; 
var b = "progressBar1";
var c = "status1";
document.getElementById("file1").disabled = true;
document.getElementById("file2").disabled = true;
uploadFile(file);
function uploadFile(file){
	_(b).style.display = "block";
	var formdata = new FormData();
	formdata.append("file2", file);
	formdata.append("userid", "<?php echo $_SESSION['id']; ?>");
	formdata.append("starttime", "<?php echo $_GET['clicktime']; ?>");
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler, false);
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "upload2.php");
	ajax.send(formdata);
}
function progressHandler(event){
	_(a).innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_(b).value = Math.round(percent);
	_(c).innerHTML = (num+1)+"번째 파일이"+Math.round(percent)+"% 업로드 중입니다."+"업로드 대기 중인 파일은 "+(_("file1").files.length-(num+1))+"개 입니다.";
}
function completeHandler(event){
	_(b).style.display = "none";
	if(event.target.responseText != "업로드 실패"
	&&event.target.responseText != "선택한 파일이 없습니다."
	&&event.target.responseText != "업로드 할 수 없는 형식의 파일입니다."
	&&event.target.responseText != "첨부할 수 있는 최대 용량은 1GB입니다.") {
	_("filelist").innerHTML += event.target.responseText;
	document.getElementById("editor").focus();
	}
	_(b).value = 0;
	num++;
	file = _("file2").files[num];
	if(num< _("file2").files.length) {
	uploadFile(file);
	}
	if(num == _("file2").files.length) {
	if(event.target.responseText == "업로드 실패"
	||event.target.responseText == "선택한 파일이 없습니다."
	||event.target.responseText == "업로드 할 수 없는 형식의 파일입니다."
	||event.target.responseText == "첨부할 수 있는 최대 용량은 1GB입니다.") {
	alert(event.target.responseText);
	} else {
	alert("업로드 성공!");
	}
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_("file1").disabled = false;
	_("file2").disabled = false;
	}
}
function errorHandler(event){
	alert("업로드를 실패하였습니다!");
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_(b).style.display = "none";
	_("file1").disabled = false;
	_("file2").disabled = false;
}
function abortHandler(event){
	alert("업로드가 중단되었습니다!");
	_(a).innerHTML = "";
	_(c).innerHTML = "";
	_(b).style.display = "none";
	_("file1").disabled = false;
	_("file2").disabled = false;
}
}
</script>

</fieldset>
<div id="editor" contentEditable="true"></div>
<fieldset>
<legend>업로드 파일 목록</legend>
<div id="filelist" style="width:100%; height:100px; border:1px solid; overflow:auto;">
</div>
</fieldset>
<iframe style="display:none;" name="delete"></iframe>
<?php if((isset($_SESSION['id']) && isset($_SESSION['username']))) { ?>
    <button onclick="apply()" style="float:right;">게시글 등록</button>
<?php } ?> 
<footer>&copy; 2019 by 공돌이광식</footer>
<script>
function apply() { //apply() 함수
	var x1 = document.getElementById("title").value.replace(/\+/,"＋").replace(/#/g,"＃").replace(/&/g,"＆").replace(/=/g,"＝")
	.replace(/\\/g,"＼");
	var x2 = document.getElementById("editor").innerHTML.replace(/\+/,"＋").replace(/#/g,"＃").replace(/&/g,"＆").replace(/=/g,"＝")
	.replace(/\\/g,"＼");
	var x3 = "<?php echo $_SESSION['id'] ?>";
	var x4 = "<?php echo $_SESSION['username'] ?>";
	var files = document.getElementById("filelist").innerHTML.replace(/\+/,"＋").replace(/#/g,"＃").replace(/&/g,"＆").replace(/=/g,"＝")
	.replace(/\\/g,"＼");
	  var x5 = new Date();
	  var days = ["일요일 ","월요일 ","화요일 ","수요일 ","목요일 ","금요일 ","토요일 "];
	  var time;
	  
	  time = x5.getFullYear()+"년 "+(x5.getMonth()+1)+"월 "+x5.getDate()+"일 "
	  +days[x5.getDay()]
	  +x5.getHours()+"시 "+x5.getMinutes()+"분";
	  
	  var obj, dbParam, xmlhttp; //obj, dbParam, xmlhttp 라는 이름을 지닌 변수
	  obj = {"table":"board","boardtitle":x1,"boardcontent":x2,"filelists":files,"userid":x3,"username":x4,"date":time,"starttime":<?php echo $_GET['clicktime']; ?>};
	//obj에 자바스크립트 객체 값을 저장함
	  dbParam = JSON.stringify(obj);
	//dbParam에 obj에 담긴 자바스크립트 객체의 값을 JSON형식의 문자열로 저장함.
	  xmlhttp = new XMLHttpRequest(); //서버에 데이터를 요청한 값을 xmlhttp변수에 저장함
	  xmlhttp.onreadystatechange = function() {
			//onreadystatechange는 xmlhttpRequest 객체의 상태가 변할 때마다 자동으로 호출할 함수를 저장함
		  if (this.readyState == 4 && this.status == 200) {//readyState 값이 4이고, status값이 200이라면 if문 안에 있는 내용을 실행함
		    myObj = JSON.parse(this.responseText);//응답받은 JSON형식의 문자열을  자바스크립트 객체 값으로 myObj에 저장
		    for (x in myObj) { //myObj에 저장한 자바스크립트 객체의 배열의 길이 값만큼 반복한다.
		    	  if(myObj[x] == '1') {
		    		  location.href='board.php';
		    		  return false;
		    	  } else {
		    		  alert("업로드 실패!");
		    	  }
		      } //for (x in myObj)에 관한 for문 종료
		  }
		};
	  if ((x1.trim() == "")||(x2.trim() == "<br>")||(x2.trim() == "")) { //x1 또는 x2의 값이 빈 값이라면
	    alert("입력된 텍스트가 없습니다."); //입력된 텍스트가 없다는 알림창을 띄운다.
	    return false; //return false를 한다.
	  } else { //x1 과 x2의 값이 모두 빈 값이 아니라면
		  document.getElementById("editor").innerHTML = "";
		  //editor 아이디를 가진 요소의 값은 없다.
		  xmlhttp.open("POST", "boardapply.php", true);
		  xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		  xmlhttp.send("x=" + dbParam); 
	  }
	}
	
function fontSize(size) {
	document.getElementById("editor").focus();
	document.execCommand("fontSize", false, size);
	document.getElementById("editor").focus();
}

function fontName(fontname) {
	document.getElementById("editor").focus();
	document.execCommand("fontName", false, fontname);
	document.getElementById("editor").focus();
}

function fontColor(fontcolors) {
	document.getElementById("editor").focus();
	document.execCommand( "foreColor", false, fontcolors);
	document.getElementById("editor").focus();
}

function underline() {
	document.getElementById("editor").focus();
	document.execCommand("underline");
	document.getElementById("editor").focus();
}

function Strikethrough() {
	document.getElementById("editor").focus();
	document.execCommand("Strikethrough");
	document.getElementById("editor").focus();
}

function bold() {
	document.getElementById("editor").focus();
	document.execCommand("bold");
	document.getElementById("editor").focus();
}

function italic() {
	document.getElementById("editor").focus();
	document.execCommand("italic");
	document.getElementById("editor").focus();
}

function sub() {
	document.getElementById("editor").focus();
	document.execCommand("subscript");
	document.getElementById("editor").focus();
}

function sup() {
	document.getElementById("editor").focus();
	document.execCommand("superscript");
	document.getElementById("editor").focus();
}

function justifyleft() {
	document.getElementById("editor").focus();
	document.execCommand("justifyleft");
	document.getElementById("editor").focus();
}

function justifycenter() {
	document.getElementById("editor").focus();
	document.execCommand("justifycenter");
	document.getElementById("editor").focus();
}

function justifyright() {
	document.getElementById("editor").focus();
	document.execCommand("justifyright");
	document.getElementById("editor").focus();
}

function justifyfull() {
	document.getElementById("editor").focus();
	document.execCommand("justifyfull");
	document.getElementById("editor").focus();
}

function insertOrderedList() {
	document.getElementById("editor").focus();
	document.execCommand("insertOrderedList");
	document.getElementById("editor").focus();
}

function insertUnorderedList() {
	document.getElementById("editor").focus();
	document.execCommand("insertUnorderedList"); 
	document.getElementById("editor").focus();
}

function indent() {
	document.getElementById("editor").focus();
	document.execCommand("indent");
	document.getElementById("editor").focus();
}

function outdent() {
	document.getElementById("editor").focus();
	document.execCommand("outdent");
	document.getElementById("editor").focus();
}

function menu_img_click() {
	x=document.getElementById('c');
	x3=document.getElementById('contents');
	x2=document.getElementById('mic');
	if (x.value == "") {
		x2.style.background = 'url(nav.png) 0 30px';
	    x3.style.display = "block";
	    x.value="1";
	  } else {
		x2.style.background = 'url(nav.png) 0 0';
	    x3.style.display = "none";
	    x.value="";
	  }
	}
</script>
</body>
</html>