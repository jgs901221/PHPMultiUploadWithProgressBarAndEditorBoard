﻿<?php header("Content-Type: text/html; charset=UTF-8"); 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>공돌이광식</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: lightgray;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>
<style type="text/css">
* {
  box-sizing: border-box;
}
@font-face {
font-family:"나눔바른펜 굵게";
src:url("NANUMPEN.TTF") format('truetype'),
url("NANUMPEN.otf") format('opentype'),
url("NANUMPEN.woff") format('woff');
}
header {
    margin-top:0px;
    padding:15px;
    width:100%;
    height:100px;
    background:black;
    text-align:center;
    font-family:"나눔바른펜 굵게";
}
header a, nav a {
    text-decoration:none;
    color:white;
}
@media only screen and (min-width:230px) { /* 창의 최소 너비 0px부터 */
	header a, nav a {
    font-size:40px;
}
nav {
height:50px;
}
}
@media only screen and (max-width:230px) and (min-width:0px) { /* 창의 최소 너비 0px부터 */
	header a, nav a {
    font-size:30px;
}
nav {
height:100px;
}
}
nav {
    width:100%;
    margin-top:10px;
    padding:10px;
    background:black;
    color:white;
    font-size:30px;
    font-family:"나눔바른펜 굵게";
}
footer {
    position: fixed;
    bottom:0;
}
div {
border:1px solid white;
}
.menu_img {
position: relative;
float:left;
width:30px;
height:30px;
background:url(nav.png) 0 0px;
border:none;
}
#contents {
display:none;
}
#contents a {
text-decoration:none;
color:black;
}
div {
border:none;
}
</style>
</head>
<body style="background:tomato;">
<header><a href="/main.php">공돌이 광식의 홈페이지</a></header>
<nav>
<div class="menu_img" id="mic" onclick="menu_img_click()"></div>
<?php if(!isset($_SESSION['id'])){ ?>
<a href="join.html" style="float:right; margin-left:10px;">회원가입</a>
<a href="login.html" style="float:right">로그인</a>
<?php } ?>
<?php if(isset($_SESSION['id'])){ ?>
<a href="logout.php" style="float:right">로그아웃</a>
<a href="joinedit.php" style="float:right;">회원정보수정</a>
<?php } ?>
</nav>
<div id="contents" style="margin-top:0; border:1px solid; position:absolute; z-index:1; background:black;"><a href="board.php" style="color:white; font-size:20px;"><b>게시판</b></a></div>
<input type="hidden" id="c" value="">

<div class="slideshow-container">

<div class="mySlides fade" style="width:50%; margin-left:auto; margin-right:auto;">
  <img src="i_love_you1.png" style="width:100%;">
</div>

<div class="mySlides fade" style="width:50%; margin-left:auto; margin-right:auto;">
  <img src="i_love_you2.png" style="width:100%;">
</div>

<div class="mySlides fade" style="width:50%; margin-left:auto; margin-right:auto;">
  <img src="i_love_you3.png" style="width:100%;">
</div>

<a style="margin-left:25%;" class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a style="margin-right:25%;" class="next" onclick="plusSlides(1)">&#10095;</a>

</div>
<br>

<div style="text-align:center">
  <span class="dot" onclick="currentSlide(1)"></span> 
  <span class="dot" onclick="currentSlide(2)"></span> 
  <span class="dot" onclick="currentSlide(3)"></span> 
</div>

<script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
num=n;
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
}
</script>
<br>
<img style="float:left; width:25%;" src="1.jpg"><br>
<img style="float:left; width:25%;" src="2.jpg"><br>
<img style="float:left; width:25%;" src="3.jpg"><br>
<img style="float:left; width:25%;" src="4.jpg"><br>
<footer>&copy; 2019 by 공돌이광식</footer>
<script type="text/javascript">
function menu_img_click() {
	x=document.getElementById('c');
	x3=document.getElementById('contents');
	x2=document.getElementById('mic');
	if (x.value == "") {
		x2.style.background = 'url(nav.png) 0 30px';
	    x3.style.display = "block";
	    x.value="1";
	  } else {
		x2.style.background = 'url(nav.png) 0 0';
	    x3.style.display = "none";
	    x.value="";
	  }
	}
</script>
</body>
</html>